import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.text.PDFTextStripper;
import org.testng.Assert;

import java.io.File;
import java.io.IOException;

public class PdfUtility {

    private static String FileName = "C:/Users/csekh_000/Downloads/AP1070856002021.pdf";
    private static File file = null;

    public static boolean checkTheTextInPDF(String docName, String Text) throws Exception {
        boolean flag = false;
        file = new File(FileName);
        PDDocument document = PDDocument.load(file);
        //Instantiate PDFTextStripper class
        PDFTextStripper pdfStripper = new PDFTextStripper();
        //Retrieving text from PDF document
        String pdfText = pdfStripper.getText(document);

        if(pdfText.contains(Text)){
            flag = true;
        }
        //Closing the document
        document.close();

    return flag;
    }

    //Extracting font details: Following code segment explains the steps to extract font details from a selected PDF page.
    public static void getFontDetails(String docName) throws IOException {
        PDDocument doc = PDDocument.load(file);
        for (int i = 0; i < doc.getNumberOfPages(); ++i) {
            PDPage page = doc.getPage(i);
            PDResources res = page.getResources();
            for (COSName fontName : res.getFontNames()) {
                PDFont font = res.getFont(fontName);
            }
        }

    }




}
