

public class BasicValidations {

    public static void main(String args[]) throws Exception {


    }
}
